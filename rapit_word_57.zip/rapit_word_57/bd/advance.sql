-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-03-2023 a las 19:38:52
-- Versión del servidor: 10.4.24-MariaDB
-- Versión de PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `advance`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id` int(100) NOT NULL,
  `codigo_categoria` varchar(20) NOT NULL,
  `nombre_categoria` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id`, `codigo_categoria`, `nombre_categoria`) VALUES
(48, '1006', 'auto'),
(52, '1007', 'Muebles'),
(53, '1008', 'telefonos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(100) NOT NULL,
  `dni_cliente` varchar(15) NOT NULL,
  `codigo_socio` varchar(15) NOT NULL,
  `numero_cuil` varchar(20) NOT NULL,
  `apellidos_cliente` varchar(50) NOT NULL,
  `nombres_cliente` varchar(50) NOT NULL,
  `fecha_de_nacimiento` date NOT NULL,
  `email_cliente` varchar(30) NOT NULL,
  `provincia` varchar(50) NOT NULL,
  `localidad` varchar(50) NOT NULL,
  `barrio` varchar(50) NOT NULL,
  `domicilio` varchar(500) NOT NULL,
  `telefono_movil` varchar(14) NOT NULL,
  `telefono_alternativo` varchar(14) NOT NULL,
  `codigo_postal` varchar(4) NOT NULL,
  `estado_civil` varchar(15) NOT NULL,
  `estado_del_cliente` varchar(10) NOT NULL,
  `fecha_de_creacion_del_cliente` date NOT NULL,
  `fecha_de_baja_del_cliente` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `dni_cliente`, `codigo_socio`, `numero_cuil`, `apellidos_cliente`, `nombres_cliente`, `fecha_de_nacimiento`, `email_cliente`, `provincia`, `localidad`, `barrio`, `domicilio`, `telefono_movil`, `telefono_alternativo`, `codigo_postal`, `estado_civil`, `estado_del_cliente`, `fecha_de_creacion_del_cliente`, `fecha_de_baja_del_cliente`) VALUES
(1, '14273521', '1001', '20142735217', 'Corzo', 'Gregorio Nicolas', '1961-10-19', 'gragorio@gmail.com', 'La Rioja', 'La Rioja', 'San Martin', 'Avda. Ramirez de Velazco 955', '(380)4595927', '(380)4432576', '5300', 'DIVORCIADO(A)', 'ACTIVO', '2020-10-30', '2020-10-30'),
(49, '15727738', '1002', '15727738', 'Marquez', 'Felix Reiiner', '1980-09-06', 'felixrx@hotmail.com', 'La rioja', 'la rioja', 'la rioja', 'la rioja', '04165632562', '04149602752', '4001', 'SOLTERO(A)', 'ACTIVO', '2022-10-24', '0000-00-00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuotas`
--

CREATE TABLE `cuotas` (
  `id_cuota` int(250) NOT NULL,
  `codigo_de_la_cuota` varchar(20) NOT NULL,
  `codigo_de_la_solicitud` varchar(20) NOT NULL,
  `codigo_de_la_sucursal` varchar(4) NOT NULL,
  `dni_cliente` varchar(15) NOT NULL,
  `codigo_plan` varchar(20) NOT NULL,
  `codigo_producto` varchar(20) NOT NULL,
  `monto_cuota` varchar(20) NOT NULL,
  `forma_de_pago` varchar(20) DEFAULT NULL,
  `nota_de_forma_de_pago` varchar(50) DEFAULT NULL,
  `cantidad_de_cuotas` varchar(3) NOT NULL,
  `numero_de_cuota` varchar(10) NOT NULL,
  `fecha_de_alta_cuota` date NOT NULL,
  `fecha_de_cobro` date NOT NULL,
  `fecha_de_pago_cuota` date DEFAULT NULL,
  `fecha_de_baja_cuota` date DEFAULT NULL,
  `estado_de_la_cuota` varchar(20) NOT NULL,
  `situacion_de_la_cuota` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `cuotas`
--

INSERT INTO `cuotas` (`id_cuota`, `codigo_de_la_cuota`, `codigo_de_la_solicitud`, `codigo_de_la_sucursal`, `dni_cliente`, `codigo_plan`, `codigo_producto`, `monto_cuota`, `forma_de_pago`, `nota_de_forma_de_pago`, `cantidad_de_cuotas`, `numero_de_cuota`, `fecha_de_alta_cuota`, `fecha_de_cobro`, `fecha_de_pago_cuota`, `fecha_de_baja_cuota`, `estado_de_la_cuota`, `situacion_de_la_cuota`) VALUES
(1, '1427352110011', '1001', '01', '14273521', '1003', '1005', '10.000.00', NULL, NULL, '12', '1', '2020-10-31', '2020-11-30', '2020-11-30', NULL, 'impaga', 'ACTIVA'),
(2, '1427352110012', '1001', '01', '14273521', '1003', '1005', '10.000.00', NULL, NULL, '12', '2', '2020-10-31', '2020-11-30', '2020-11-30', NULL, 'paga', 'ACTIVA'),
(3, '1427352110013', '1001', '01', '14273521', '1003', '1005', '10.000.00', NULL, NULL, '12', '3', '2020-10-30', '2020-12-31', '2020-12-30', '2021-01-01', 'impaga', 'MORA'),
(540, '1572773810021', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '1', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(541, '1572773810022', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '2', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(542, '1572773810023', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '3', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(543, '1572773810024', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '4', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(544, '1572773810021', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '1', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(545, '1572773810022', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '2', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(546, '1572773810023', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '3', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(547, '1572773810024', '1002', '', '15727738', '1003', '1032', '2.000,00', NULL, NULL, '4', '4', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(548, '1572773810031', '1003', '', '15727738', '1004', '1033', '2.000,00', NULL, NULL, '3', '1', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(549, '1572773810032', '1003', '', '15727738', '1004', '1033', '2.000,00', NULL, NULL, '3', '2', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(550, '1572773810033', '1003', '', '15727738', '1004', '1033', '2.000,00', NULL, NULL, '3', '3', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(551, '1572773810031', '1003', '', '15727738', '1004', '1033', '2.000,00', NULL, NULL, '3', '1', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(552, '1572773810032', '1003', '', '15727738', '1004', '1033', '2.000,00', NULL, NULL, '3', '2', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', ''),
(553, '1572773810033', '1003', '', '15727738', '1004', '1033', '2.000,00', NULL, NULL, '3', '3', '0000-00-00', '2022-10-26', NULL, NULL, 'IMPAGA', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `id_empleado` int(10) NOT NULL,
  `codigo_empleado` varchar(20) NOT NULL,
  `dni_empleado` varchar(25) NOT NULL,
  `apellido_empleado` varchar(50) NOT NULL,
  `nombre_empleado` varchar(50) NOT NULL,
  `email_empledo` varchar(50) NOT NULL,
  `sucursal_empleado` varchar(50) NOT NULL,
  `fecha_de_nacimiento` date NOT NULL,
  `estado_del_empleado` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id_empleado`, `codigo_empleado`, `dni_empleado`, `apellido_empleado`, `nombre_empleado`, `email_empledo`, `sucursal_empleado`, `fecha_de_nacimiento`, `estado_del_empleado`) VALUES
(1, '1000', '15727738', 'Marquez', 'Felix', 'felixrx25@hotmail.com', 'La Rioja', '2016-12-19', 'activo'),
(9, '1001', '29604115', 'Corzo', 'Pablo', 'pncorzo@gmail.com', 'La Rioja', '1982-08-13', 'Activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marca`
--

CREATE TABLE `marca` (
  `id` int(100) NOT NULL,
  `codigo_marca` varchar(100) NOT NULL,
  `nombre_marca` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `marca`
--

INSERT INTO `marca` (`id`, `codigo_marca`, `nombre_marca`) VALUES
(25, '1006', 'sankey'),
(26, '1007', 'Ford'),
(27, '1008', 'samsung'),
(28, '1009', 'samsung');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planes`
--

CREATE TABLE `planes` (
  `id` int(20) NOT NULL,
  `codigo_plan` varchar(20) NOT NULL,
  `nombre_del_plan` varchar(100) NOT NULL,
  `producto` varchar(200) NOT NULL,
  `cantidad_de_cuotas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `planes`
--

INSERT INTO `planes` (`id`, `codigo_plan`, `nombre_del_plan`, `producto`, `cantidad_de_cuotas`) VALUES
(103, '1003', '4 Ruedas', '', '3'),
(104, '1004', 'MotoPlan', '', '3'),
(105, '1005', 'UniPlan', '', '3'),
(106, '1006', 'UniPersonal', '', '3'),
(107, '1007', 'mi casa', '', '2'),
(108, '1008', 'gold', '', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(100) NOT NULL,
  `codigo_producto` varchar(20) NOT NULL,
  `codigo_plan` varchar(200) NOT NULL,
  `nombre_producto` varchar(250) NOT NULL,
  `descripcion_producto` varchar(250) NOT NULL,
  `modelo` varchar(250) NOT NULL,
  `a_o` varchar(250) NOT NULL,
  `kilometraje` varchar(200) NOT NULL,
  `codigo_marca` varchar(250) NOT NULL,
  `codigo_categoria` varchar(250) NOT NULL,
  `precio_producto` varchar(250) NOT NULL,
  `cuota_producto` varchar(250) NOT NULL,
  `stock_producto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `codigo_producto`, `codigo_plan`, `nombre_producto`, `descripcion_producto`, `modelo`, `a_o`, `kilometraje`, `codigo_marca`, `codigo_categoria`, `precio_producto`, `cuota_producto`, `stock_producto`) VALUES
(35, '1031', '1005', 'auto', 'auto', 'ford', '2010', '200000', '1006', '1006', '44', '44', '44'),
(44, '1032', '1003', 'cama', 'cama', '', '', '', '1006', '1007', '2,22', '2,22', '222'),
(47, '1033', '1004', 'telefono', 'telefono', '', '', '', '1008', '1008', '2.000,00', '10', '10');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `id_solicitud` int(50) NOT NULL,
  `codigo_de_la_solicitud` varchar(20) NOT NULL,
  `dni_cliente` varchar(20) NOT NULL,
  `codigo_plan` varchar(20) NOT NULL,
  `codigo_producto` varchar(20) NOT NULL,
  `fecha_de_la_solicitud` date NOT NULL,
  `bonificacion` varchar(20) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `fecha_de_cobro` date NOT NULL,
  `codigo_empleado` varchar(10) NOT NULL,
  `codigo_de_la_sucursal` varchar(10) NOT NULL,
  `fecha_de_baja_de_la_solicitud` date DEFAULT NULL,
  `estado_de_la_solicitud` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`id_solicitud`, `codigo_de_la_solicitud`, `dni_cliente`, `codigo_plan`, `codigo_producto`, `fecha_de_la_solicitud`, `bonificacion`, `descripcion`, `fecha_de_cobro`, `codigo_empleado`, `codigo_de_la_sucursal`, `fecha_de_baja_de_la_solicitud`, `estado_de_la_solicitud`) VALUES
(1, '1001', '14273521', '1003', '1005', '2020-11-30', '2.000.00', 'GASTOS ADMINISTRATIVOS', '2020-10-31', '1001', '01', NULL, 'ACTIVA'),
(2316, '1002', '15727738', '1003', '1032', '0000-00-00', '20,00', 'producto comprado', '0000-00-00', '1001', '1002', NULL, 'ACTIVA'),
(2317, '1003', '15727738', '1004', '1033', '0000-00-00', '20,00', 'La ', '0000-00-00', '1001', '1002', NULL, 'ACTIVA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sucursales`
--

CREATE TABLE `sucursales` (
  `id_sucursal` int(4) NOT NULL,
  `codigo_de_la_sucursal` varchar(4) NOT NULL,
  `nombre_sucursal` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sucursales`
--

INSERT INTO `sucursales` (`id_sucursal`, `codigo_de_la_sucursal`, `nombre_sucursal`) VALUES
(1, '01', 'La Rioja'),
(2, '02', 'San Juan'),
(3, '03', 'Catamarca'),
(4, '04', 'Santiago del Estero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(10) NOT NULL,
  `codigo_usuario` int(20) NOT NULL,
  `tipo_de_usuario` varchar(40) NOT NULL,
  `nick_usuario` varchar(15) NOT NULL,
  `clave` varchar(40) NOT NULL,
  `nivel` int(10) NOT NULL,
  `nombre_del_usuario` varchar(50) NOT NULL,
  `nombre_sucursal` varchar(20) NOT NULL,
  `codigo_de_la_sucursal` varchar(10) NOT NULL,
  `estado_usuario` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `codigo_usuario`, `tipo_de_usuario`, `nick_usuario`, `clave`, `nivel`, `nombre_del_usuario`, `nombre_sucursal`, `codigo_de_la_sucursal`, `estado_usuario`) VALUES
(10, 1012, 'administrador', 'felixrx', '123', 1, 'felix marquez', 'San Juan', '02', 'activo'),
(1013, 1013, 'administrador', 'admin', '123', 1, 'Pablo Corzo', 'La Rioja', '01', 'activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Indices de la tabla `cuotas`
--
ALTER TABLE `cuotas`
  ADD PRIMARY KEY (`id_cuota`);

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id_empleado`);

--
-- Indices de la tabla `marca`
--
ALTER TABLE `marca`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `planes`
--
ALTER TABLE `planes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`id_solicitud`);

--
-- Indices de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  ADD PRIMARY KEY (`id_sucursal`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT de la tabla `cuotas`
--
ALTER TABLE `cuotas`
  MODIFY `id_cuota` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=554;

--
-- AUTO_INCREMENT de la tabla `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id_empleado` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `marca`
--
ALTER TABLE `marca`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `planes`
--
ALTER TABLE `planes`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `id_solicitud` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2318;

--
-- AUTO_INCREMENT de la tabla `sucursales`
--
ALTER TABLE `sucursales`
  MODIFY `id_sucursal` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1015;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
