
 
<!DOCTYPE html>



<html lang="en" >

<head>
  <meta charset="UTF-8">


  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">



    <link rel="shortcut icon" type="image/ico" href="../imagenes/favicon.ico"/>
  <title>Login</title>
  <link href="../css/material.css" rel="stylesheet">
  
  <link rel='stylesheet' href='../css/materialize.min.css'>




  
</head>



<body style="padding: 0px; display: flex; flex-direction: column; height: 100vh; margin: 0px;background-color: #e4eef7; ">


  <div class="container" >

<div class="row">

<div class="col s12" style=" text-align: center;"><img style="text-align: center; width: 200px; height: 70px;" src="../imagenes/logo.png" ></div>

</div>

<div class="row">

<div class="" style="height: 1px;"></div>



<div id="login-page"  class="col  s12 m12 l12" style="padding-right: 15px;  padding-left: 15px; padding-bottom: 180px; ">



   
   



    <div class="col s12  m8 l6   offset-m2  offset-l3 z-depth-6 card-panel" style=" border-radius: 4px;border-radius: 4px 4px 4px 4px; background-color: #5b93cb !important; ">




      <form class="login-form" method="post" action="sesion.php">
        <div class="row">
        </div>
         <div class="row">
          <div class="input-field col s12">
            <i class="material-icons prefix"style="color: #f8f6e7;">account_circle</i>
            <input  id="email" name="txtusuario" autocomplete="off" tabindex="1"  autofocus class="focusNext" style="color: #f8f6e7; font-weight: bold;font-size: 20;border-bottom-color: white !important; border-width: 2px;" required="true" type="text">
            <label for="email" data-error="wrong" data-success="right" style="color: #f8f6e7;font-weight: bold;">Usuario</label>
          </div>
        </div>
         <div class="row">
          <div class="input-field col s12">
            <i class="material-icons prefix" style="color: #f8f6e7";>lock_outline</i>
            <input id="password" type="password" name="txtclave" autocomplete="off" tabindex="2"  class="focusNext" style="color: #f8f6e7; border-bottom-color: white !important; border-width: 2px;">
            <label for="password" style="color: #f8f6e7; font-weight: bold;">Clave</label>
          </div>
        </div>
        <div class="row">          
          <div class="input-field col s12 m12 l12  login-text">
              <input type="checkbox" id="remember-me" style="color: #f8f6e7;" />
              <label for="remember-me" style="color: #f8f6e7;">Recordarme</label>
          </div>
        </div>
   
          
           
        <div class="row" >  

                
          <div class="input-field col s12 m12 l12  login-text" style="float: right;">
              <input value="Entrar" class="btn waves-light col s3" type="submit" style="border-radius:4px 4px 4px 4px; box-shadow: 0 0 20px #36393c;  " style="color: #f8f6e7; float:right; align-items: center;"  >

          </div>
        </div>
         
       
        <div class="row">
          <div class="input-field col s6 m6 l6" style="color: #f8f6e7;" >
            
          </div>
          <div class="input-field col s6 m6 l6" style="color: #f8f6e7;" >
             
          </div>          
        </div>

      </form>
    </div>
  </div> 

</div>


</div>






</body>
  <script src='../js/angular.min.js'></script>
<script src='../js/jquery.min.js'></script>
<script src='../js/materialize.min.js'></script>

  

    <script type="text/javascript">

  document.addEventListener('keypress', function(evt) {

  // Si el evento NO es una tecla Enter
  if (evt.key !== 'Enter') {
    return;

    alert();
  }
  
  let element = evt.target;

  // Si el evento NO fue lanzado por un elemento con class "focusNext"
  if (!element.classList.contains('focusNext')) {
    return;
  }

  // AQUI logica para encontrar el siguiente
  let tabIndex = element.tabIndex + 1;
  var next = document.querySelector('[tabindex="'+tabIndex+'"]');

  // Si encontramos un elemento
  if (next) {
    next.focus();
    event.preventDefault();
  }
});



</script>  




</body>

</html>
 



</body>

</html>