
<?php
session_start();
include_once('../conexion/conexion.php');

error_reporting(0);

$usuario = $_POST['txtusuario'];
$clave = $_POST['txtclave'];
$nivel_admin = 0;
$nivel_user = 1;

if ( $usuario != '' or $clave != '' )
	{
	// Buscar Datos
	$querybuscar = $mysqli->query("SELECT * FROM usuario where nick_usuario='$usuario' and clave='$clave'");
	while (($fila=mysqli_fetch_array($querybuscar)))
	{
		$usuariobd= $fila['nick_usuario'];
		$clavebd= $fila['clave'];
		$nivelbd= $fila['nivel'];
		$nombre= $fila['nombre'];

		$sucursal= $fila['sucursal'];
		$codigo_de_la_sucursal= $fila['codigo_de_la_sucursal'];
		$id= $fila['id'];
	}





if( $usuario == $usuariobd && $clave == $clavebd)
	{
		


if( $usuario == $usuariobd && $clave == $clavebd && $nivel_admin== $nivelbd )
	{
		
		$_SESSION['autenticado'] = true;
		$_SESSION['usuario'] = $usuario;
		$_SESSION['nivel'] = $nivel_admin;
		$_SESSION['id'] = $id;

		$_SESSION['vendedor'] = $vendedor;
		$_SESSION['sucursal'] = $sucursal;
		$_SESSION['codigo_de_la_sucursal'] = $codigo_de_la_sucursal;
		$_SESSION['clave'] = $clave;

		header("Location: ../usuario/usuario.php");
		


	}


elseif( $usuario == $usuariobd && $clave == $clavebd && $nivel_user== $nivelbd)
	{
		$_SESSION['autenticado'] = true;
		$_SESSION['usuario'] = $usuario;
		$_SESSION['nivel'] = $nivel_user;
		$_SESSION['id'] = $id;
		$_SESSION['clave'] = $clave;
		$_SESSION['codigo_de_la_sucursal'] = $codigo_de_la_sucursal;
		$_SESSION['sucursal'] = $sucursal;
		$_SESSION['vendedor'] = $vendedor;

		
		


		echo '<script type="text/javascript">
   window.location.href = "../admin/index.php";
</script>';
		
	}
	}

else{
		


			echo '<script type="text/javascript">
   window.location.href = "login.php?error=si";
</script>';
	}

}
?>