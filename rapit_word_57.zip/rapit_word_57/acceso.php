<?php

error_reporting(0);

if(!$_SESSION['autenticado'])
{
	




		echo '<script type="text/javascript">
   window.location.href = "../admin"
</script>';

}



?>