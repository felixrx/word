<?php
/**
 * Trabajar con documentos de Word y PHP usando PHPOffice
 *
 * Más tutoriales en: parzibyte.me/blog
 *
 * Ejemplo 1.1:
 * Crear y descargar documento de word, poner propiedades,
 * guardar para versiones actuales y
 * establecer idioma
 */
require_once "vendor/autoload.php";
use PhpOffice\PhpWord\Style\Language;
use PhpOffice\PhpWord\Style\Alignment;
use PhpOffice\PhpWord\SimpleType\Jc;
$documento = new \PhpOffice\PhpWord\PhpWord();
$propiedades = $documento->getDocInfo();


$imagenSrc=$_POST["imagen"];



  $contador = count($_POST["nombreImagen"]);
    $ProContador=0;



    
$seccion = $documento->addSection();

$encabezado = $seccion->addHeader();


$estiloTabla1 = [
    "width" => 900,
    "height" => 60,
    "borderColor" => "blue",
    "alignment" => Jc::CENTER,
    "borderSize" => 0,
    "cellMargin" => 0,
 ];

$estiloTabla2 = [
    "width" => 900,
    "height" => 60,
    "borderColor" => "red",

   

];
// Guardarlo para usarlo más tarde
$documento->addTableStyle("estilo2", $estiloTabla2);
$fuente = [

    "name" => "Arial",
    "size" => 5,
    "color" => "black",
    "italic" => false,
    "alignment" => Jc::CENTER,
    "cellMargin" => 45,
    
    "bold" => true,
    
    
    
	 
];

$fuenteCelda = [
    "name" => "ArialNarrow",
    "size" => 9.5,
    "color" => "000000",
    "italic" => false,
    "alignment" => Jc::CENTER,
    "cellMargin" => 0,
    "bold" => true,
    
    
    
	 
];

$fuenteCelda2 = [
    "name" => "Calibri",
    "size" => 10,
    "color" => "000000",
    "italic" => false,
    "alignment" => Jc::CENTER,
    "cellMargin" => 0,
    "bold" => false,
    
    
    
     
];


$tabla = $encabezado->addTable("estilo1"); # Agregar tabla con el estilo que guardamos antes


$styleTable = array('borderSize' => 6, 'borderColor' => '999999',);
$documento->addTableStyle("estilo1", $estiloTabla2);


$celda = $tabla->addRow(300);
$celda->addCell(1850, array('vMerge' => 'restart'))->addImage('logo.png', [
    "width" => 440,
     "height" => 58,
     "alignment" => Jc::CENTER,
    
]);  

$fuente2 = [
    "name" => "Arial",
    "size" => 7,
    "color" => "000000",
    "italic" => false,
     "cellMargin" => 45,
  
    "bold" => true,
    "borderSize" => 30,
    
   
];








$fuenteTitulo = [
    "name" => "calibri",
    "size" => 9,
    "color" => "000000",
    "bold" => true,
    
   'alignment' => \PhpOffice\PhpWord\SimpleType\Jc::CENTER, 
    'align' => \PhpOffice\PhpWord\Style\Cell::VALIGN_CENTER,
    
];

$fuenteTitulo2 = [
    "size" => 10,
    "color" => "0431B4",
    'underline' => 'single',
    "bold" => true,
    "name" => 'calibri(cuerpo)',
    
   'alignment' => \PhpOffice\PhpWord\SimpleType\Jc::CENTER, 
    'align' => \PhpOffice\PhpWord\Style\Cell::VALIGN_CENTER,
    
];
$fuenteLinkCentrado = [
    "name" => "calibri",
    "size" => 10,
    "color" => "000000",
    "bold" => true,
    'underline' => 'single',
    
   'alignment' => \PhpOffice\PhpWord\SimpleType\Jc::CENTER, 
    'align' => \PhpOffice\PhpWord\Style\Cell::VALIGN_CENTER,
    
];


$fuenteLinkCorreo = [
    "name" => "calibri",
    "size" => 10,
    "color" => "000000",
    "bold" => true,
    'underline' => 'single',
    
  
    
];

$fuenteHeader = [
    "name" => "calibri",
    "size" => 10,
    "color" => "000000",
    "bold" => true,
    
   'alignment' => \PhpOffice\PhpWord\SimpleType\Jc::CENTER, 
    'align' => \PhpOffice\PhpWord\Style\Cell::VALIGN_CENTER,
    
];



$multipleTabsStyleName = 'multipleTab';
$documento->addParagraphStyle(
    $multipleTabsStyleName,
    array(
        'tabs' => array(
            new \PhpOffice\PhpWord\Style\Tab('left', 950),
            
        ),
    )
);

$fuenteTab = [
    "name" => "calibri",
    "size" => 10,
    "color" => "000000",
    'underline' => 'single',
    "bold" => true,
    'tabs' => array(
            new \PhpOffice\PhpWord\Style\Tab('left', 950),
            
        ),
];

$fuenteTabParrafo2 = [
    "name" => "calibri",
    "size" => 10,
    "color" => "000000",
    "bold" => true,
    'tabs' => array(
            new \PhpOffice\PhpWord\Style\Tab('left', 950),
            
        ),
];

// New portrait section


// Add listitem elements








$footer = $seccion->addFooter();
$textrun = $footer->addTextRun();

// define bold style



$documento->addParagraphStyle(
    'multipleTab',

    array(
        'tabs' => array(
           
            new \PhpOffice\PhpWord\Style\Tab('right', 5600),


        ),
       
 

    )
);




$boldFontStyleName = 'BoldText';
$documento->addFontStyle($boldFontStyleName, array('bold' => true, "name" => "calibri",
    "size" => 10,
    "color" => "0431B4",
    'underline' => 'single',
    "bold" => true,
    "name" => 'calibri(cuerpo)'));
    


$tabla = $encabezado->addText("REGISTRO FOTOGRAFICO ", $fuenteTitulo, [  
     "alignment" => Jc::CENTER,
    

   
]);
$tabla = $encabezado->addTable("estilo1");



      for($i=0;$i<$contador;$i++)     {
     
        $ProContador++;


if (is_array($imagenSrc) || is_object($imagenSrc))
{

    foreach ($imagenSrc as $imagenSrc)
    {   



$estiloTabla2 = [
    "borderColor" => "black",
    "alignment" => Jc::CENTER,
    "borderSize" => 4,
      
];








// Guardarlo para usarlo más tarde


$styleTable2 = array(
    'borderSize' => 9, 
    'borderColor' => 'black',
    "cellMargin" => 75,
    'alignment' => Jc::CENTER);

$documento->addTableStyle('Colspan Rowspan', $styleTable2);
$seccion->addTextBreak();
$table = $seccion->addTable('Colspan Rowspan');




$celda = $table->addRow();




$celda->addCell(1000, array('gridSpan' => 2, 'vMerge' => 'restart'))->addImage($imagenSrc, [
    "width" => 315,
    "height" => 188,
    "cellMargin" => 120,
    "alignment" => Jc::CENTER,

]);  
$celda = $table->addRow();




$celda->addCell(1000, array('gridSpan' => 2, 'vMerge' => 'restart'))->addText('OBSERVACION',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>120,



   
]);

$celda = $table->addRow();




$celda->addCell(1000, array('gridSpan' => 2, 'vMerge' => 'restart'))->addText('',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" => 120,


   
]);






      
# Títulos. Solo modificando depth (el número)




    }
}

       
      };

      




# Para que no diga que se abre en modo de compatibilidad
$documento->getCompatibility()->setOoxmlVersion(15);
# Idioma español de México
$documento->getSettings()->setThemeFontLang(new Language("ES-MX"));
# Enviar encabezados para indicar que vamos a enviar un documento de Word



$nombre ='Mirs-Fecha:'.date("d-m-Y").'_'.'Hora:'.date("h-i-sa").'.docx';
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $nombre . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Expires: 0');
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($documento, "Word2007");
# Y lo enviamos a php://output
$objWriter->save("php://output");



