<?php

if (isset($_FILES["imagen"]))
{

 
    $cantidad= count($_FILES["imagen"]["tmp_name"]);
    
   $reporte = null;

    for ($i=0; $i<$cantidad; $i++){
   
$patch='./';  
   

$max_ancho = 300;
$max_alto = 200;

    
    if ($_FILES['imagen']['type'][$i]=='image/png' || $_FILES['imagen']['type'][$i]=='image/jpeg'){



$medidasimagen= getimagesize($_FILES['imagen']['tmp_name'][$i]);


    if($medidasimagen[0] < 1280 && $_FILES['imagen']['size'][$i] < 100000){

    $nombrearchivo=$_FILES['imagen']['name'][$i];


}else {

$nombrearchivo=$_FILES['imagen']['name'][$i];

//Redimensionar
$rtOriginal=$_FILES['imagen']['tmp_name'][$i];

if($_FILES['imagen']['type'][$i]=='image/jpeg'){
$original = imagecreatefromjpeg($rtOriginal);
}
else if($_FILES['imagen']['type'][$i]=='image/png'){
$original = imagecreatefrompng($rtOriginal);
}

else if($_FILES['imagen']['type'][$i]=='image/jpg'){
$original = imagecreatefromjpeg($rtOriginal);
}
else if($_FILES['imagen']['type']=='image/gif'){
$original = imagecreatefromgif($rtOriginal);
}

 
list($ancho,$alto)=getimagesize($rtOriginal);

$x_ratio = $max_ancho / $ancho;
$y_ratio = $max_alto / $alto;


if( ($ancho <= $max_ancho) && ($alto <= $max_alto) ){
    $ancho_final = $ancho;
    $alto_final = $alto;
}
elseif (($x_ratio * $alto) < $max_alto){
    $alto_final = ceil($x_ratio * $alto);
    $ancho_final = $max_ancho;
}
else{
    $ancho_final = ceil($y_ratio * $ancho);
    $alto_final = $max_alto;
}

$lienzo=imagecreatetruecolor($ancho_final,$alto_final); 

imagecopyresampled($lienzo,$original,0,0,0,0,$ancho_final, $alto_final,$ancho,$alto);
 
imagedestroy($original);
 
$cal=8;

if($_FILES['imagen']['type'][$i]=='image/jpeg'){
imagejpeg($lienzo,$patch."/".$nombrearchivo);
}
else if($_FILES['imagen']['type'][$i]=='image/png'){
imagepng($lienzo,$patch."/".$nombrearchivo);
}
else if($_FILES['imagen']['type'][$i]=='image/gif'){
imagegif($lienzo,$patch."/".$nombrearchivo);
}

}


    $validar=true;
    }
    else $validar=false;
    
   

 echo '<form action="../pages/vistas/plantilla_2/plantilla_2.php" method="post" target="_self"  enctype="multipart/form-data">';
  {

        $src = $patch.$nombrearchivo;
        move_uploaded_file($patch, $src);
       
echo '
      

  <p>

 <input type="hidden" name="imagen[]" value="'.$src.'">
  <input type="hidden" name="nombreImagen[]" value="'.$nombrearchivo.'">

  </p>

';


}

 echo '
    <div class="custom-input-file " id="boton" style="float:left;  background-color: ; margin-bottom:100px;border-radius: 4px 4px 4px 4px;">
 <input type="submit"   class="input-file"   style="border-style:none;"     name="enviar" id="enviar"  >
 <i class="fas fa-file-word-o"  style=" font-size: 35px;"></i>
Generar Archivos Word...
</div>
    </form>';
        echo $reporte; 

}
 
    



