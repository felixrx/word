
<?php sleep(2); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	 <meta charset="UTF-8">
	 <title>Generar Archivos Word </title>    
    <meta name="viewport" content="width=device-width, initial-scale=1">
  

</head>


<body>

<!-- AREA DE MODALES -->
<div>
    

<!--  FIN AREA DE MODALES -->
</div>

                        <!-- MultiStep Form -->
<div class="container-fluid mt-5">
    <div class="row justify-content-center mt-0">
        <div class="col-10 col-sm-10 col-md-10 col-lg-10 text-center p-0  mb-2">
            <div class="card " >
                  <div class="col-md-12 " style="float: left; text-align: center; border-radius: 5px 5px 0px 0px; background-color: #5b93cb;">
                    <p style="color: white; font-size: 15px; font-weight: bold; ; margin:0px; padding:0px;">GENERAR ARCHIVOS WORD PLANTILLA Nº 2</p>
                  </div>               
                    <div class="row">
                       <div class="col-md-12 mx-0" style="">
                           <section class="wizard-section">
                              <div class="container">
                               <div class="row">
                                <div class="col-12" >
                                  <div class="table-responsive" style=" float: left;">

                                       
          <!--  CARGA LA TABLA  -->    <div class="col-xs-12">
                                         
                                         
            



 <div   class="col-md-12" style="   height: 100px;">
    
    
    <div style="float: left; padding-top: 15px;">
    <form method="post"   action="multiple-ajax_2.php" target="" id="formulario" enctype="multipart/form-data">
 

    <div class="custom-input-file "  id="buscar" style="float:left;border-radius: 4px 4px 4px 4px;">
 <input type="file" id="file" name="imagen[]" multiple  class="input-file"> 
 <i class="fas fa-search"  style=" font-size: 35px;"></i>

Buscar imagenes
</div>


    
 </form>


     <div class="custom-input-file " id="boton_2" style="float:left;  background-color: ; margin-bottom:20px;border-radius: 4px 4px 4px 4px;">
 <input type="button" id="btn_2"  class="input-file"  >
 <i class="fas fa-upload"  style=" font-size: 35px;"></i>
Subir Imagenes...
</div>
    </div> 
   <div id="respuesta"  class="col-md-4" style="background-color: ; padding-top:  5px; "></div> 
  </div>


 <div   class="col-md-12" style="background-color: ; margin-bottom: 20px;" >
    

 <div class="col-md-12" id="vista-previa" ></div>

  <div id="myDiv" style="background-color:;  align-content: center;  text-align: center; align-items: center; align-self: center; ">

    <div   class="col-md-12"  style=" align-content: center;align-self: center;  text-align: center; align-items: center;">

 <div style=" z-index: 9990; position: relative; align-content: center;align-self: center;  text-align: center; align-items: center;  top:  "  >
        <img id="loading-image" src="../imagenes/loader.gif" style="display:none; width: 100px; height: 100px;"/>

</div>

          <div id="xprogress"  aria-valuenow='0' aria-valuemin='0' aria-valuemax='100' style="color:rgb(51, 255, 73) ; z-index: 9999;    align-content: center; align-self: center; text-align: center; position: relative; bottom: 45px; align-items: center; font-size:12px;color: #45a8e1;"  ></div>
                               </div> 

</div>
    </div>



 


   
</div>




          <!--  FIN DE LA TABLA  -->   </div>
                                   </div>

                                 
                              </div>
                            </div>
                          </section>
                      </div>
                  </div>
            </div>
          </div>
        </div>
    </div>
          




<style type="text/css">
    .custom-input-file {
  background-color: #5b93cb;
  color: #fff;
  cursor: pointer;
  font-size: 18px;
  font-weight: bold;
  margin: 0 auto 0;
  min-height: 15px;
  overflow: hidden;
  padding: 10px;
  position: relative;
  text-align: center;
  width: 400px;
}

.custom-input-file .input-file {
 border: 10000px solid transparent;
 cursor: pointer;
 font-size: 10000px;
 margin: 0;
 opacity: 0;
 outline: 0 none;
 padding: 0;
 position: absolute;
 right: -1000px;
 top: -1000px;
}
</style>




<!-- librerias java scipt -->

                          

 <script type="text/javascript">





var PI4 = {

    onReady : function() { 


           $("#boton_2").hide();

    }


}
    

    $(document).ready(PI4.onReady);

</script>





                                       <script>




var PI3 = {

    onReady : function() {                                        
    
       $("#file").on("change", function(){
           /* Limpiar vista previa */
           $("#vista-previa").html('');
           var archivos = document.getElementById('file').files;
           var navegador = window.URL || window.webkitURL;
           /* Recorrer los archivos */
           for(x=0; x<archivos.length; x++)
           {
               /* Validar tamaño y tipo de archivo */
               var size = archivos[x].size;
               var type = archivos[x].type;
               var name = archivos[x].name;
               if (size > 4048*4048)
               {
                   $("#vista-previa").append("<p style='color: red'>El archivo "+name+" supera el máximo permitido 1MB</p>");
               }
               else if(type != 'image/jpeg' && type != 'image/jpg' && type != 'image/png' && type != 'image/gif')
               {
                   $("#vista-previa").append("<p style='color: red'>El archivo "+name+" no es del tipo de imagen permitida.</p>");
               }
               else
               {
                 var objeto_url = navegador.createObjectURL(archivos[x]);
                 $("#vista-previa").append("<img src="+objeto_url+" width='200' height='200' style='border: 5px solid black;margin: 5px;'>");

               }


           }



            if (objeto_url= true) {



                $("#boton_2").show();




                  $("#buscar").hide();


 $("#vista-previa").show();

            


            }
            else{
                    $("#boton_2").hide();

            }
 
       });




       
     }

}








 $(document).ready(PI3.onReady);









  
    </script>












    <script type="text/javascript">
        
window.setTimeout(
 function(){

async function doAjax(args) {
    const result = await $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: args
    });

    return result;
}

var PI2 = {

    onReady : function() { 

       $("#btn_2").on("click", function(){
            var formData = new FormData($("#formulario")[0]);
            var ruta = "multiple-ajax_2.php";

            async function doAjax(args) {
           const result = await $.ajax({
                url: ruta,
                type: "POST",
                data: formData,
                cache:true,

                 global: true,

                  method: 'POST',
  
    

                 ifModified:true,

               
                contentType: false,
                processData: false,
                 async: true,

                beforeSend: function() {
              $("#loading-image").show();
               $("#vista-previa").hide();
           },

            
                success: function(datos)

                {

                      $("#loading-image").hide();
                    $("#respuesta").html(datos);


                     $("#boton_2").hide();

                    $("#xprogress").html('');

                },
                      xhr: function() {
              var xhr = new window.XMLHttpRequest();

              xhr.upload.addEventListener("progress", function(evt) {
                if (evt.lengthComputable) {
                  var percentComplete = evt.loaded / evt.total;
                  percentComplete = parseInt(percentComplete * 100);
                  console.log(percentComplete);
                  
                  $("#xprogress").html(+ percentComplete +"%");

                 


                }
              }, false);

              return xhr;
            }




            }); return result;

}});

  $(document).ready(PI2.onReady);

  },5000);

    </script>
</body>
</html>