<?php

if (isset($_FILES["imagen"]))
{


   $reporte = null;

 $cantidad= count($_FILES["imagen"]["tmp_name"]);


     for($x=0; $x<$cantidad; $x++)
    {
    $file = $_FILES["imagen"];
    $nombre = $file["name"][$x];
    $tipo = $file["type"][$x];
    $ruta_provisional = $file["tmp_name"][$x];
    $size = $file["size"][$x];
    $dimensiones = getimagesize($ruta_provisional);
    $width = $dimensiones[0];
    $height = $dimensiones[1];
    $carpeta = './';
    
    if ($tipo != 'image/jpeg' && $tipo != 'image/jpg' && $tipo != 'image/png' && $tipo != 'image/gif')
    {
        $reporte .= "<p style='color: red'>Error $nombre, el archivo no es una imagen.</p>";
    }
    else if($size > 4048*4048)
    {
        $reporte .= "<p style='color: red'>Error $nombre, el tamaño máximo permitido es 1mb</p>";
    }
    else if($width > 5000 || $height > 5000)
    {
        $reporte .= "<p style='color: red'>Error $nombre, la anchura y la altura máxima permitida es de 500px</p>";
    }
    else if($width < 120 || $height < 120)
    {
        $reporte .= "<p style='color: red'>Error $nombre, la anchura y la altura mínima permitida es de 60px</p>";
    }
    else
        echo '<form action="plantilla_2.php" method="post" target="_blank"  enctype="multipart/form-data">';
    {
        $src = $carpeta.$nombre;
        move_uploaded_file($ruta_provisional, $src);
       
echo '
      

  <p>

 <input type="hidden" name="imagen[]" value="'.$src.'">
  <input type="hidden" name="nombreImagen[]" value="'.$nombre.'">

  </p>

';
         
    }


    }

     echo '
    <div class="custom-input-file " id="boton" style="float:left;  background-color: ; margin-bottom:20px;">
 <input type="submit"   class="input-file"  id="generar"  style="border-style:none;"     name="enviar" id="enviar"  >
 <i class="fas fa-file-word-o"  style=" font-size: 35px;"></i>
Generar Archivos Word..
</div>>
    </form>';
        echo $reporte;

};

?>