<!DOCTYPE HTML>
<html>
 <head>
     <meta charset="UTF-8">
  <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
   <script>
     $(function(){   
       $("#file").on("change", function(){
           /* Limpiar vista previa */
           $("#vista-previa").html('');
           var archivos = document.getElementById('file').files;
           var navegador = window.URL || window.webkitURL;
           /* Recorrer los archivos */
           for(x=0; x<archivos.length; x++)
           {
               /* Validar tamaño y tipo de archivo */
               var size = archivos[x].size;
               var type = archivos[x].type;
               var name = archivos[x].name;
               if (size > 4048*4048)
               {
                   $("#vista-previa").append("<p style='color: red'>El archivo "+name+" supera el máximo permitido 1MB</p>");
               }
               else if(type != 'image/jpeg' && type != 'image/jpg' && type != 'image/png' && type != 'image/gif')
               {
                   $("#vista-previa").append("<p style='color: red'>El archivo "+name+" no es del tipo de imagen permitida.</p>");
               }
               else
               {
                 var objeto_url = navegador.createObjectURL(archivos[x]);
                 $("#vista-previa").append("<img src="+objeto_url+" width='200' height='200' style='border: 5px solid black;margin: 5px;'>");
               }
           }
       });
       
       $("#btn").on("click", function(){
            var formData = new FormData($("#formulario")[0]);
            var ruta = "multiple-ajax.php";
            $.ajax({
                url: ruta,
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(datos)
                {
                    $("#respuesta").html(datos);

                }
            });
           });
       
     });

  
    </script>
 </head>
 <body>

 <div style=" width: 900px; height: 50px;">
 	
 	
 	<div style="float: left; padding-top: 15px;">
 	<form method="post" id="formulario" enctype="multipart/form-data">
    Seleccionar imagenes: <input type="file" id="file" name="file[]" multiple>
    <button type="button" id="btn">Subir imágenes</button>
 </form>
 	</div> 
 	<div id="respuesta" style="float: left; padding-left: 40px; padding-top: 0px;"></div> 

  </div>
 <div id="vista-previa"></div>
  
 </body>
</html>