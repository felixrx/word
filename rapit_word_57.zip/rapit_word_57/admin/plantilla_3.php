<?php

require_once "vendor/autoload.php";


$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord->addSection();
use PhpOffice\PhpWord\SimpleType\Jc;

use PhpOffice\PhpWord\Style\Cell;




use PhpOffice\PhpWord\SimpleType\JcTable;

$styleTable = array(
    'borderSize' => 6,
    'borderColor' => '000000',
    "width" => 2120,
    
);

$fuenteCelda = [
    "name" => "Arial",
    "size" => 8.5,
    "color" => "000000",
    "italic" => false,
    "alignment" => Jc::CENTER,
    "cellMargin" => 0,
    "bold" => true,
    
    
    
     
];




$header = $section->addHeader();





$table = $header->addTable(['alignment' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER]);
$table->addRow(1200,array("exactHeight" => true));



$table->addCell(2000, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addImage('recuadro.png',[
    "width" => 100,
    "height" => 65,


   

]);



$table->addCell(7100, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('OBJETO CONTRACTUAL',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
     $table->addCell(2000, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addImage('recuadro.png',[
    "width" => 100,
    "height" => 65,


   

]);



 $table = $header->addTable(['alignment' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER]);


$table->addRow(350,array("exactHeight" => true));


$table->addCell(2000, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('PERIODO:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'left',
     'spaceAfter' => 0,



   
]);
$table->addCell(9100, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 0,"alignment" => Jc::LEFT,
     "cellMargin" =>0])->addText('',$fuenteCelda, [  
     "alignment" => Jc::LEFT,
     "cellMargin" =>0,
     'align' => 'left',
     'spaceAfter' => 0,



   
]);


 $table = $header->addTable();


$table->addRow(350,array("exactHeight" => true));
$table->addCell(2000, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 0,"alignment" => Jc::LEFT,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::LEFT,
     "cellMargin" =>0,
     'align' => 'left',
     'spaceAfter' => 0,
]);

$table->addCell(3500, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 0,"alignment" => Jc::LEFT,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::LEFT,
     "cellMargin" =>0,
     'align' => 'left',
     'spaceAfter' => 0,
]);

$table->addCell(3550, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' =>0,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'left',
     'spaceAfter' => 0,
]);

$table->addCell(2050, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 0,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'left',
     'spaceAfter' => 0,
]);

















$phpWord->addTableStyle('myCustomTable', $styleTable);



$foto_array = $_POST['nombreImagen'];

$grupos = array_chunk($foto_array, 4);
$numero=0;
foreach ($grupos as $grupo) {

    $numero++;
    // Add two images at the top
    $table = $section->addTable('myCustomTable');
    $table->addRow(4100, array("exactHeight" => true));

     // Add two images at the bottom
  


    foreach (array_slice($grupo, 0, 2) as $imagen) {
        $cell = $table->addCell(4100, [
            'borderLeftSize' => 0,
            'borderSize' => 3,
            'borderStyle' => 'double',
            'borderColor' => '000000',
            'valign' => 'center',
            'alignment' => Jc::CENTER,
            'cellMargin' => 0
        ]);

        $cell->addImage($imagen, [
            'width' => 235,
            'height' => 203
        ]);
    }

    // Add table with project name
    $table = $section->addTable();
   
$table->addRow(340,array("exactHeight" => true));
$table->addCell(900, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('FOTO Nº',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(400, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000'])->addText('');
$table->addCell(3400, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('OBSERVACIONES:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(900, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('FOTO Nº',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(400, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000'])->addText('');
$table->addCell(3400, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('OBSERVACIONES:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,


]);

  $table = $section->addTable();
   
$table->addRow(1000,array("exactHeight" => true));
$table->addCell(4700, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,
]);

$table->addCell(4700, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,
]);





    $table->setWidth(1350);



$section->addText(''); // Agregar texto vacío


$table = $section->addTable();


    // Add two images at the bottom
   $table->addRow(4100, array("exactHeight" => true));


  
    foreach (array_slice($grupo, 2, 2) as $imagen) {
        $cell = $table->addCell(4100, [
            'borderLeftSize' => 0,
            'borderSize' => 3,
            'borderStyle' => 'double',
            'borderColor' => '000000',
            'valign' => 'center',
            'alignment' => Jc::CENTER,
            'cellMargin' => 0
        ]);

        $cell->addImage($imagen, [
            'width' => 235,
            'height' => 203
        ]);
    }

    // Add table with project name
    $table = $section->addTable();
   
$table->addRow(340,array("exactHeight" => true));
$table->addCell(507, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('FOTO Nº',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(400, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000'])->addText('');
$table->addCell(3200, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('OBSERVACIONES:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(900, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('FOTO Nº',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(400, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000'])->addText('');
$table->addCell(3400, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('OBSERVACIONES:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,


]);

  $table = $section->addTable();
   
$table->addRow(1000,array("exactHeight" => true));
$table->addCell(4100, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,
]);

$table->addCell(4100, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText(' ',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,
]);


}

    $table->setWidth(1350);






// más esto:
header('Content-Type:application/force-download');

header('Pragma:public');





$nombre ='Mirs-Fecha:'.date("d-m-Y").'_'.'Hora:'.date("h-i-sa").'.docx';
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $nombre . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Expires: 0');
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, "Word2007");
# Y lo enviamos a php://output



ob_end_clean();
$objWriter->save("php://output");




