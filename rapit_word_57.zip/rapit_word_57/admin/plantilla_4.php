<?php

require_once "vendor/autoload.php";


$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord->addSection();
use PhpOffice\PhpWord\SimpleType\Jc;

use PhpOffice\PhpWord\Style\Cell;




use PhpOffice\PhpWord\SimpleType\JcTable;

$styleTable = array(
    'borderSize' => 6,
    'borderColor' => '000000',
    "width" => 2000,
    
);

$fuenteCelda = [
    "name" => "Arial",
    "size" => 8.5,
    "color" => "000000",
    "italic" => false,
    "alignment" => Jc::CENTER,
    "cellMargin" => 0,
    "bold" => true,
    
    
    
     
];




$header = $section->addHeader();





$table = $header->addTable(['alignment' => \PhpOffice\PhpWord\SimpleType\JcTable::CENTER]);
$table->addRow(990,array("exactHeight" => true));

$table->addCell(750,  ['borderLeftSize' => 0, 'borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addImage('recuadro.png',[
    "width" => 60,
    "height" => 50,]);

$table->addCell(3450, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('REGISTRO FOTOGRÁFICO',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);

     $table->setWidth(1340);

$table->setWidth(1350);
$table->addCell(1350, ['borderLeftSize' => 0, 'borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addImage('recuadro.png',[
    "width" => 65,
    "height" => 50,


   

]);




$table->setWidth(1350);
$table->addCell(1350, ['borderLeftSize' => 0, 'borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addImage('recuadro.png',[
    "width" => 65,
    "height" => 50,


   

]);



$table->setWidth(1350);
$table->addCell(1350, ['borderLeftSize' => 0, 'borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addImage('recuadro.png',[
    "width" => 65,
    "height" => 50,


   

]);



$table->addRow(350,array("exactHeight" => true));

$table->addCell(1000, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('PROYECTO:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(4300, ['gridSpan' => 4, 'vMerge' => 'restart','borderSize' => 3, 'borderStyle' => 'double','borderColor' => '000000'])->addText('');


$table->addRow(340,array("exactHeight" => true));
$table->addCell(1000, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('PERIODO:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(3480, ['borderSize' => 3,'borderStyle' => 'double', 'borderColor' => '000000'])->addText('');
$table->addCell(1000, ['borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000','valign' => 'center'
    ,'indent' => 2.5,"alignment" => Jc::CENTER,
     "cellMargin" =>0])->addText('AREA:',$fuenteCelda, [  
     "alignment" => Jc::CENTER,
     "cellMargin" =>0,
     'align' => 'center',
     'spaceAfter' => 0,



   
]);
$table->addCell(3600, ['gridSpan' => 2, 'vMerge' => 'restart','borderSize' => 3, 'borderStyle' => 'double', 'borderColor' => '000000'])->addText('');



















$phpWord->addTableStyle('myCustomTable', $styleTable);
$foto_array = $_POST['nombreImagen'];

$grupos = array_chunk($foto_array, 4);

foreach ($grupos as $grupo) {
    // Add two images at the top
    $table = $section->addTable('myCustomTable');
    $table->addRow(4000, array("exactHeight" => true));

    foreach (array_slice($grupo, 0, 2) as $imagen) {
        $cell = $table->addCell(5000, [
            'borderLeftSize' => 0,
            'borderSize' => 3,
            'borderStyle' => 'double',
            'borderColor' => '000000',
            'valign' => 'center',
            'alignment' => Jc::CENTER,
            'cellMargin' => 0
        ]);

        $cell->addImage($imagen, [
            'width' => 230,
            'height' => 203
        ]);
    }

    // Add table with headers
    $table = $section->addTable();
    $table->addRow();
    $table->addCell(6000, [
        'borderLeftSize' => 0,
        'borderSize' => 3,
        'borderStyle' => 'double',
        'borderColor' => '000000',
        'valign' => 'center',
        'alignment' => Jc::CENTER,
        'cellMargin' => 0
    ])->addText('Foto', $fuenteCelda, [
        'alignment' => Jc::CENTER,
        'cellMargin' => 0,
        'align' => 'center',
        'spaceAfter' => 0
    ]);

    $table->addCell(6000, [
        'borderSize' => 3,
        'borderStyle' => 'double',
        'borderColor' => '000000',
        'valign' => 'center',
        'indent' => 2.5,
        'alignment' => Jc::CENTER,
        'cellMargin' => 0,
        'width' => 215
    ])->addText('REGISTRO FOTOGRÁFICO', $fuenteCelda, [
        'alignment' => Jc::CENTER,
        'cellMargin' => 0,
        'align' => 'center',
        'spaceAfter' => 0
    ]);

    $table->setWidth(1340);

    // Add two images at the bottom
    $table->addRow();

    foreach (array_slice($grupo, 2, 2) as $imagen) {
        $cell = $table->addCell(5000, [
            'borderLeftSize' => 0,
            'borderSize' => 3,
            'borderStyle' => 'double',
            'borderColor' => '000000',
            'valign' => 'center',
            'alignment' => Jc::CENTER,
            'cellMargin' => 0
        ]);

        $cell->addImage($imagen, [
            'width' => 230,
            'height' => 203
        ]);
    }

    // Add table with project name
    $table = $section->addTable();
    $table->addRow();

    $table->addCell(1000, [
        'borderSize' => 3,
        'borderStyle' => 'double',
        'borderColor' => '000000',
        'valign' => 'center',
        'indent' => 2.5,
        'alignment' => Jc::CENTER,
        "cellMargin" => 0
    ])->addText('PROYECTO:', $fuenteCelda, [
        "alignment" => Jc::CENTER,
        "cellMargin" => 0,
        "align" => "center",
        "spaceAfter" => 0
    ]);

    $table->addCell(2600, [
        "gridSpan" => 2,
        "vMerge" => "restart",
        "borderSize" => 3,
        "borderStyle" => "double",
        "borderColor" => "000000"
    ])->addText('');

    // Add two empty cells
    $table->addRow();

    foreach (array_slice($grupo, 2, 2) as $imagen) {
        $cell = $table->addCell(1000);
    }
}






// más esto:
header('Content-Type:application/force-download');

header('Pragma:public');





$nombre ='Mirs-Fecha:'.date("d-m-Y").'_'.'Hora:'.date("h-i-sa").'.docx';
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $nombre . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Expires: 0');
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, "Word2007");
# Y lo enviamos a php://output



ob_end_clean();
$objWriter->save("php://output");




