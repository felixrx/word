$imagenes = $_POST['nombreImagen'];

$grupos = array_chunk($imagenes, 4);
foreach ($grupos as $grupo) {
    $table = $section->addTable('myCustomTable');
    $table->addRow(4000, array("exactHeight" => true));
   
    foreach (array_slice($grupo, 0, 2) as $imagen) {
        $cell = $table->addCell(5000, [
            'borderLeftSize' => 0, 
            'borderSize' => 3,
            'borderStyle' => 'double', 
            'borderColor' => '000000',
            'valign' => 'center',
            'alignment' => Jc::CENTER,
            'cellMargin' => 0
        ]);

        $cell->addImage($imagen, [
            "width" => 230,
            "height" => 203
        ]);
    }

    // Add table header
    $table = $section->addTable();
    $table->addRow();
    $table->addCell(6000, [
        'borderLeftSize' => 0, 
        'borderSize' => 3,
        'borderStyle' => 'double', 
        'borderColor' => '000000',
        'valign' => 'center',
        'alignment' => Jc::CENTER,
        'cellMargin' => 0
    ])->addText('Foto',$fuenteCelda, [  
        "alignment" => Jc::CENTER,
        "cellMargin" =>0,
        'align' => 'center',
        'spaceAfter' => 0,
    ]);

    $table->addCell(6000, [
        'borderSize' => 3, 
        'borderStyle' => 'double', 
        'borderColor' => '000000',
        'valign' => 'center',
        'indent' => 2.5,
        "alignment" => Jc::CENTER,
        "cellMargin" =>0
    ])->addText('REGISTRO FOTOGRÁFICO',$fuenteCelda, [  
        "alignment" => Jc::CENTER,
        "cellMargin" =>0,
        'align' => 'center',
        'spaceAfter' => 0,
        "width" => 215,
    ]);

    $table->setWidth(1340);
    $table->addRow(350,array("exactHeight" => true));
    $table->addCell(1000, [
        'borderSize' => 3,
        'borderStyle' => 'double',
        'borderColor' => '000000',
        'valign' => 'center',
        'indent' => 2.5,
        "alignment" => Jc::CENTER,
        "cellMargin" =>0
    ])->addText('PROYECTO:',$fuenteCelda, [  
        "alignment" => Jc::CENTER,
        "cellMargin" =>0,
        'align' => 'center',
        'spaceAfter' => 0,
    ]);

    $table->addCell(2600, [
        'gridSpan' => 2, 
        'vMerge' => 'restart',
        'borderSize' => 3, 
        'borderStyle' => 'double', 
        'borderColor' => '000000'
    ])->addText('');

    foreach (array_slice($grupo, 2, 2) as $imagen) {
        // Add cells for the remaining images
        $cell=$table->addCell(1000)->addText($fuenteCelda, [  
            "alignment" => Jc::CENTER,
            "cellMargin" =>0,
        ]);
    }

    // Add two images below the table
    $table->addRow();
   
    foreach (array_slice($grupo, 2, 2) as $imagen) {
        $cell = $table->addCell(5000, [
            'borderLeftSize' => 0, 
            'borderSize' => 3,
            'borderStyle' => 'double', 
            'borderColor' => '000000',
            'valign' => 'center',
            "alignment" => Jc::CENTER,
            "cellMargin" =>0
        ]);

        $cell->addImage($imagen, [
            "width" => 230,
            "height" => 203
        ]);
    }
}