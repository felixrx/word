
 const ooUpdate = document.getElementById('online');

        if (navigator.onLine) {
         
            ooUpdate.style.color = '#33FF49';
        }

        // Add Event Listeners

        window.addEventListener('online', function(){
            
            ooUpdate.style.color = '#33FF49';
        })

        window.addEventListener('offline', function(){
           
            ooUpdate.style.color = '#FF3333';
        });