<?php   



$dir = './';
array_map('unlink', glob("{$dir}*.jpg"));

array_map('unlink', glob("{$dir}*.jpeg"));

array_map('unlink', glob("{$dir}*.gif"));

