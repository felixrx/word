
$phpWord->getCompatibility()->setOoxmlVersion(15);








ob_end_clean();

// más esto:
header('Content-Type:application/force-download');

header('Pragma:public');

header('Cache-Control:no-cache,must-revalidate,post-check=0,pre-check=0');
header('Cache-Control:private,false');










$nombre ='Mirs-Fecha:'.date("d-m-Y").'_'.'Hora:'.date("h-i-sa").'.docx';
header("Content-Description: File Transfer");
header('Content-Disposition: attachment; filename="' . $nombre . '"');
header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
header('Expires: 100');
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, "Word2007");
# Y lo enviamos a php://output
$objWriter->save("php://output");
