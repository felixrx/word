


<?php

  $destino = './';
  $nombresImagenes = array();
  
  foreach ($_FILES["imagen"]["tmp_name"] as $key => $tmp_name) {
    $nombreImagen = generarNombreArchivo($_FILES["imagen"]["name"][$key]);
    $rutaImagen = $destino . $nombreImagen;
    redimensionarImagen($tmp_name, $rutaImagen, 600, 300);
    array_push($nombresImagenes, $nombreImagen);
  }

  if (!empty($nombresImagenes)) {
    print '<form action="plantilla_3.php" method="post" target="_blank" enctype="multipart/form-data">';
    foreach ($nombresImagenes as $nombreImagen) {
      print '<input type="hidden" name="nombreImagen[]" value="' . $nombreImagen . '">';
    }
    print '<button type="submit">Generar Archivos Word...</button>';
    print '</form>';
  }


function generarNombreArchivo($nombreOriginal) {
  $extension = pathinfo($nombreOriginal, PATHINFO_EXTENSION);
  return uniqid() . '.' . $extension;
}

function redimensionarImagen($rutaImagenOriginal, $rutaDestino, $maxAncho, $maxAlto) {
  list($ancho, $alto) = getimagesize($rutaImagenOriginal);
  $xRatio = $maxAncho / $ancho;
  $yRatio = $maxAlto / $alto;

  if (($ancho <= $maxAncho) && ($alto <= $maxAlto)) {
    $anchoFinal = $ancho;
    $altoFinal = $alto;
  } elseif (($xRatio * $alto) < $maxAlto) {
    $altoFinal = ceil($xRatio * $alto);
    $anchoFinal = $maxAncho;
  } else {
    $anchoFinal = ceil($yRatio * $ancho);
    $altoFinal = $maxAlto;
  }

  $lienzo = imagecreatetruecolor($anchoFinal, $altoFinal);
  $original = imagecreatefromjpeg($rutaImagenOriginal);
  imagecopyresampled($lienzo, $original, 0, 0, 0, 0, $anchoFinal, $altoFinal, $ancho, $alto);

  imagejpeg($lienzo, $rutaDestino);
}

?>