


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Dashboard | Sistema Advance La Rioja</title>


  <link rel="shortcut icon" type="image/ico" href="../imagenes/favicon.ico"/>

 
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">

    <link rel="stylesheet" href="dist/css/spinerPreloader.css">
  <script src="plugins/jquery/jquery.min.js"></script>

    <link rel='stylesheet' href='css/dataTables.bootstrap4.min.css'>

  <link rel="stylesheet" href="dist/css/estiloformulario.css">
<link rel="stylesheet" href="plugins/font-awesome/css/font-awesome.min.css">


   <link rel="stylesheet" href="css/tabla.css">



    <link rel="stylesheet" href="../css/estilos_planes.css" type="text/css" media="screen"/>



</head>

<?php  



error_reporting(0);

?>

<body class=" sidebar-mini sidebar-collapse"  style="background-color: white !important; margin: 0px !important; padding: 0px !important;
display: flex; flex-direction: column; height: 100vh;">

 
  <script>
    const runClock = () => {
      const date = new Date();
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const fullYear = date.getFullYear();
      const hours = date.getHours();
      const minutes = date.getMinutes();
      const seconds = date.getSeconds();
      const clock = document.getElementById('clock');
      clock.innerHTML = `${day}/${month}/${fullYear} ${hours}:${minutes}:${seconds}`;
    };
    setInterval(runClock, 1000);
  </script> 


<div class="wrapper" >

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->



     <ul class="navbar-nav">
      <li class="nav-item">


        <a class="nav-link" id="link2" data-widget="pushmenu" href="#"><i class="fas fa-bars" id="link"></i></a>



      </li>
     
    </ul>

       <ul class="navbar-nav" style="float: left; clear: both;">
      <li class="nav-item">


        <a class="nav-link" id="link2" data-widget="pushmenu" href="#"><i  id="link"><div style="font-size:11px;" id="clock"></div></i></a>



      </li>
     
    </ul>



   

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->

       <li class="nav-item dropdown">
        <a class="nav-link"  href="" >
          <i class="fa fa fa-wifi fa-1x" id="online" ></i>
          
        </a>


      
      </li>


      <li class="nav-item dropdown">
        <a class="nav-link"  href=""id="refresh">
          <i class="fa fa-refresh fa-1x" ></i>
          
        </a>


      
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link"  href="../login/cerrar_sesion.php">
          <i class="fa fa-sign-out fa-2x"></i>
          
        </a>


      
      </li>
      <!-- Notifications Dropdown Menu -->
    
     
    </ul>

     <style type="text/css">
      .online_off{
        color: #FD0202;
      }

       .online_on{
        color: #93FF33;
      }
    </style>



    <script>
       
    </script>

    <script type="text/javascript">


  
   /* 	setIdleTimeout(240000, function() {
    $("#msg").text("Why you leave me?");

                $('#salir').click();
        

}, 


function() {
    $("#msg").text("Welcome back!");
});



function setIdleTimeout(millis, onIdle, onUnidle) {
    var timeout = 0;
    $(startTimer);

    function startTimer() {
        timeout = setTimeout(onExpires, millis);
        $(document).on("mousemove keypress", onActivity);
    }
    
    function onExpires() {
        timeout = 0;
        onIdle();
    }

    function onActivity() {
        if (timeout) clearTimeout(timeout);
        else onUnidle();
        //since the mouse is moving, we turn off our event hooks for 1 second
        $(document).off("mousemove keypress", onActivity);
        setTimeout(startTimer, 1000);
    }
}*/
    </script>

    <p id="msg">  </p>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->

<style type="text/css">
	.sidebar-dark-primary{
		background-color: #5b93cb !important;
	}
</style>


  <aside class="main-sidebar  sidebar-dark-primary elevation-4 " id="as" style="animation-duration: 0s; ">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-4"
           style="opacity: .9">
      <span class="nav-item " style="color:white;">Rapid Word</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex" style=" padding: 0px !important;margin-top: 3px !important; padding-top: 2px !important; margin-bottom: 0px !important; ">
        <div class="image">
          <i style="color: white;" class="nav-icon fa fa-user-circle-o fa-1x"></i>
        </div>
        <div class="info">
          <a href="#" class="d-block" style="font-size: 12px;font-weight: bold; color: white;"><?php  echo "".$_SESSION['usuario'];?>
          	<?php  echo "".$_SESSION['vendedor'];?>
          </a>
        </div>
      </div>
        <div class="user-panel mt-3 pb-3 mb-3 d-flex" style="padding: 0px !important; padding-top: 2px !important; margin-bottom: 3px !important; margin-top: 0px !important;">
        <div class="image">
          <i style="color: white;" class="nav-icon fa fa-home fa-1x"></i>
        </div>
        <div class="info">
          <a href="#" class="d-block" style="font-size: 12px;font-weight: bold; color: white;">
          	<?php  echo "".$_SESSION['sucursal'].' - '. $_SESSION['codigo_de_la_sucursal'];?>
          </a>
        </div>
        
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" id="ul" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

<style type="text/css">
  ul.nav.nav-pills li > * {
  color: white;
}

ul.nav.nav-pills li > * :hover {
  color: grey;
}

ul.nav.nav-pills li > * :focus {
  color: #227190;
}

* {
	margin: 0;
	padding: 0;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
}


.accordion2 :hover {
background-color: #white;
border-radius: 5px;
-webkit-box-shadow: -1px 0px 5px -1px rgba(0,0,0,0.75);
-moz-box-shadow: -1px 0px 5px -1px rgba(0,0,0,0.75);
box-shadow: -1px 0px 5px -1px rgba(0,0,0,0.75);



}





/** =======================
 * Contenedor Principal
 ===========================*/
h1 {
 	color: #FFF;
 	font-size: 24px;
 	font-weight: 400;
 	text-align: center;
 	margin-top: 80px;
 }

h1 a {
 	color: #c12c42;
 	font-size: 16px;
 }

 .accordion {
 	width: 100%;
 	max-width: 360px;
 	margin: 0px auto 20px;
 	background: #FFF;
 	-webkit-border-radius: 4px;
 	-moz-border-radius: 4px;
 	border-radius: 4px;
 }

.accordion .link {
	cursor: pointer;
	display: block;
	padding: 15px 15px 15px 42px;
	
	font-size: 14px;
	font-weight: 700;
	border-bottom: 1px solid #CCC;
	position: relative;
	-webkit-transition: all 0.4s ease;
	-o-transition: all 0.4s ease;
	transition: all 0.4s ease;
}

 p:hover {

color: red;
}



.accordion li:last-child .link {
	border-bottom: 0;
}

.accordion li i {
	position: absolute;
	top: 16px;
	left: 12px;
	font-size: 18px;
	color: #595959;
	-webkit-transition: all 0.4s ease;
	-o-transition: all 0.4s ease;
	transition: all 0.4s ease;
}

.accordion li i.fa-chevron-down {
	right: 12px;
	left: auto;
	font-size: 16px;
}

.accordion li.open .link {
	color: #b63b4d;

}

.accordion li.open i {
	color: #b63b4d;
}
.accordion li.open i.fa-chevron-down {
	-webkit-transform: rotate(180deg);
	-ms-transform: rotate(180deg);
	-o-transform: rotate(180deg);
	transform: rotate(180deg);
}

.accordion li.default .submenu {display: block;}
/**
 * Submenu
 -----------------------------*/
 .submenu {
 	display: none;
 	background: none;
 	font-size: 14px;
 	border:none;
 }

 .submenu li {
 	
 }

 .submenu a {
 	display: block;
 	text-decoration: none;
 	
 	
 	-webkit-transition: all 0.25s ease;
 	-o-transition: all 0.25s ease;
 	
 }

 .submenu a:hover {
 	background: transparent;
 	box-shadow: none;
 	color: #FFF;
 }



</style>

<script type="text/javascript">
	$(function() {
	var Accordion = function(el, multiple) {
		this.el = el || {};
		this.multiple = multiple || false;

		// Variables privadas
		var links = this.el.find('.link');
		// Evento
		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
	}

	Accordion.prototype.dropdown = function(e) {
		var $el = e.data.el;
			$this = $(this),
			$next = $this.next();

		$next.slideToggle();
		$this.parent().toggleClass('open');

		if (!e.data.multiple) {
			$el.find('.submenu').not($next).slideUp().parent().removeClass('open');
		};
	}	

	var accordion = new Accordion($('.accordion2'), false);
});
</script>

	<!-- Contenedor -->
	


<ul  class="accordion accordion2" style="">
		<li  class="nav-item " style="">
			<div class="link " style="padding-left:  50px; height: 45px;  color: #5b93cb;font-weight: bold;">
				<i style="color: #5b93cb; margin-right: 15px; box-shadow: none; " class="nav-icon fas fa-list-ul"></i>
				<p style="padding-left: 8px; font-weight: bold; font-size: 15; width: 10px; box-shadow: none; color:#5b93cb;  ">PLANTILLAS</p>
				<i style="color: #5b93cb; box-shadow: none; font-size: 10px;" class="fa fa-chevron-down" ></i></div>
			<ul class="submenu">
				<li  class="nav-item " style="">
			<div class="link " style="padding-left:  50px; height: 45px;  color: #5b93cb;font-weight: bold;">
				<i style="color: #5b93cb; margin-right: 15px; box-shadow: none; " class="nav-icon fas fa-file-word-o"></i>
				<a href="#" class="zona"  id="plantilla_1"><p style="padding-left: 10px; font-weight: bold; font-size: 15; width: 10px; box-shadow: none; color:#5b93cb;  ">
				PLANTILLA Nº 1
				</p></a>
				</div>
													
		</li>
					<li  class="nav-item " style="">
			<div class="link " style="padding-left:  50px; height: 45px;  color: #5b93cb;font-weight: bold;">
				<i style="color: #5b93cb; margin-right: 15px; box-shadow: none; " class="nav-icon fas fa-file-word-o"></i>
				<a href="#"  id="plantilla_2" class="zona"><p style="padding-left: 10px; font-weight: bold; font-size: 15; width: 10px; box-shadow: none; color:#5b93cb;  ">
					PLANTILLA Nº 2
				</p></a>
				</div>
			
		</li>

	
				
			</ul>
		</li>	
	</ul>

    

 
      
     
   

	
	
          
        


	





          <li class="nav-item" >
           <a class="nav-link"  href="../login/cerrar_sesion.php">
          <i class="fa fa-sign-out fa-2x"id="salir"></i>
           <p style="font-weight: bold;">
                Salir
              
              </p>
          
        </a>
          </li>

      </ul>
             
            </nav>
       
      
     

       
    
    </div>
  
  </aside>




  
  <div class="content-wrapper" >
   
   
  
    <section class="content" style="margin: 0px; padding: 0px;">
      <div class="container-fluid" style="margin: 0px; padding: 0px;">

<div class="col-md-9" id="img" style=" height: 400px; position: absolute; text-align: center;z-index: 1;
position: absolute; top: 15px; margin: 0px; padding: 0px;" >


			<div class="col-md-4"  style="  text-align: center;float: left;" ></div>
			<div class="col-md-4" id="image"  style="   text-align: center;float: left;" ></div>
			<div class="col-md-4" style="    text-align: center;float: left;" ></div>


		</div>
<div  id="mostrar"   >
	

 
</div>
 <div  id="mostrar2" >

  <div   class="col-md-12  col-xs-12 col-sm-12" style=" float: left;">
  
  <div  class="col-md-12 col-xs-12 col-sm-12" style=" margin-top: 100px;  ">

  	<div class="col-md-2 col-sm-1" style="height: 1px; float: left; "></div>
    
      <div class="col-md-8 col-lg-8 col-xs-6 col-sm-10 " style=" float: left;  text-align: center;  ">
      	<img style="text-align: center; margin: 0px !important; padding: 0px !important;
display: flex; flex-direction: column; height: 22vh; " class="col-md-9 col-xs-12  col-sm-12 col-lg-8 " src="../imagenes/logo.png" ></div>
  </div>
  
</div>

 </section>
</div>
</section>
</div>
</nav>
</nav>
</div>
</aside>
</div>
</body>

    <script type="text/javascript">


                $(document).ready(function() {

     

                 $(".fa-refresh").click(function(){
                  var id = $(this).attr('id');


                  $("#mostrar").load('index.php #mostrar');

                  




});



                 $(".zona").click(function(event){
                 	var id = $(this).attr('id');
                 	
                 		
                 		event.preventDefault();

                              

                   


                 if ( id =='plantilla_1'){              		
			

                 	
                 	  $.ajax({
                         type: "POST",
                        url: "../pages/vistas/plantilla_1/vista_1.php", //Mando a ajaxdatos.php
                        
                      beforeSend: function(){ 
                      $("#mostrar2").fadeOut("slow");
                      $("#mostrar").fadeOut("slow");                    

			$("#img").html(""+
			"<div class='spiner2'>"+
		"<div class='loading-wave'>"+
		"<div class='rect1'></div>"+
		  "<div class='rect2'></div>"+
		  "<div class='rect3'></div>"+
		  "<div class='rect4'></div>"+
		  "<div class='rect5'></div>"+
			"</div></div>").fadeIn("slow");
			
					
						
						},
                        success: function(response1) {
                                          
						$("#img").html(""+
	"<div class='spiner2'>"+
"<div class='loading-wave'>"+
"<div class='rect1'></div>"+
  "<div class='rect2'></div>"+
  "<div class='rect3'></div>"+
  "<div class='rect4'></div>"+
  "<div class='rect5'></div>"+
"</div></div>").fadeOut("slow");
						$('#mostrar').html(response1).fadeIn("slow");

      	

                  }

            });

			

                 	

                 };







    if ( id =='plantilla_2'){              		
			

                 	
                 	  $.ajax({
                         type: "POST",
                        url: "vista_2.php", //Mando a ajaxdatos.php
                        
                      beforeSend: function(){ 
                      $("#mostrar2").fadeOut("slow");
                      $("#mostrar").fadeOut("slow");                    

			$("#img").html(""+
			"<div class='spiner2'>"+
		"<div class='loading-wave'>"+
		"<div class='rect1'></div>"+
		  "<div class='rect2'></div>"+
		  "<div class='rect3'></div>"+
		  "<div class='rect4'></div>"+
		  "<div class='rect5'></div>"+
			"</div></div>").fadeIn("slow");
			
					
						
						},
                        success: function(response1) {
                                          
						$("#img").html(""+
	"<div class='spiner2'>"+
"<div class='loading-wave'>"+
"<div class='rect1'></div>"+
  "<div class='rect2'></div>"+
  "<div class='rect3'></div>"+
  "<div class='rect4'></div>"+
  "<div class='rect5'></div>"+
"</div></div>").fadeOut("slow");
						$('#mostrar').html(response1).fadeIn("slow");

      	

                  }

            });

			

                 	

                 };


















    if ( id =='3'){                 
      

                  
                    $.ajax({
                         type: "POST",
                        url: "../pages/vistas/plantilla_3/vista_3.php", //Mando a ajaxdatos.php
                        
                      beforeSend: function(){ 
                      $("#mostrar2").fadeOut("slow");
                      $("#mostrar").fadeOut("slow");                    

      $("#img").html(""+
      "<div class='spiner2'>"+
    "<div class='loading-wave'>"+
    "<div class='rect1'></div>"+
      "<div class='rect2'></div>"+
      "<div class='rect3'></div>"+
      "<div class='rect4'></div>"+
      "<div class='rect5'></div>"+
      "</div></div>").fadeIn("slow");
      
          
            
            },
                        success: function(response1) {
                                          
            $("#img").html(""+
  "<div class='spiner2'>"+
"<div class='loading-wave'>"+
"<div class='rect1'></div>"+
  "<div class='rect2'></div>"+
  "<div class='rect3'></div>"+
  "<div class='rect4'></div>"+
  "<div class='rect5'></div>"+
"</div></div>").fadeOut("slow");
            $('#mostrar').html(response1).fadeIn("slow");

        

                  }

            });

      

                  

                 };













































            
  });
        





            });
                 



                       
                  

   
             
            </script>









   <script type="text/javascript">

   	
	

	$(document).ready(function(){
	

    
        $('body').on("keydown", function(e) { 



 if (e.shiftKey && e.which === 83) {
                
                e.preventDefault();
                $('#clientes').click();
           
            };



            if (e.shiftKey && e.which === 83) {
                
                e.preventDefault();
                $('#clientes').click();
           
            };
             if (e.shiftKey && e.which === 80) {
                
                e.preventDefault();
                $('#plan').click();
           
            };


             if (e.shiftKey && e.which === 67) {
                
                e.preventDefault();
                $('#categoria').click();
           
            };

 		if (e.shiftKey && e.which === 78) {
                
                e.preventDefault();
                $('#agregar_solicitud').click();
           
            };

           


       

        if (e.shiftKey && e.which === 88) {
                
                e.preventDefault();
                $('#cerrar').click();
           
            };


             if (e.shiftKey && e.which === 81) {
                
                e.preventDefault();
                $('#salir').click();
               

                
           
            };

             if (e.shiftKey && e.which === 82) {
                
                e.preventDefault();
                  location.reload();
               


          
            };




 
             if (e.shiftKey && e.which === 81 ) {
                
                e.preventDefault();
                $('#salir').click();
               

                
           
            };



            if (e.shiftKey &&  e.altKey && e.which === 78  ) {
                
                e.preventDefault();
                $('#agregar_plan').click();
               

                
           
            };


       });







document.addEventListener("keydown", function(event){
	alert(event.which);
});









	});
</script>


       
   
<script type="text/javascript">
	
	jQuery(document).ready(function($) {

       $('body').keypress(function(e) {
           if(e.which == '76') {}


             

                
           
         
              
       });


});
jQuery.fn.simulateKeyPress = function(character) {
       jQuery(this).trigger({
           type: 'keypress',
           which: character
       });
};

    setTimeout(function() {
       $('body').simulateKeyPress(76);
    }, 1000);
</script>
 


                                       <script>


                                        $(document).ready( function(){
               




       


 $(document).on('submit', 'form', function (evt) {
  
   $("#buscar").toggle();
$("#boton").toggle();


 $("#vista-previa").hide();



 });


       
     });

  
    </script>

<script type="text/javascript">
   
</script>



<script type="text/javascript" src="js/javaScriptWizar.js"></script>

<script src="dist/js/adminlte.min.js"></script>


<script src="js/sweetalert2@9.js"></script>
 

<script src="dist/js/estiloformulario.js"></script>
 
 <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

 <script type="text/javascript" src="js/comprobar_conexion.js"></script>




</html>
